/**
 * @author Saif Ali
 * @summary Maintains contactform Component.
 * @version 1.0
 */
 import axios from "axios";
 import { useRef } from "react";
export const Contactform = ()=>{
  let nameInputBox = useRef(null);
     let emailInputBox = useRef(null);
     let dobInputBox = useRef(null);
     let genderInputBox = useRef(null);
     let addressInputBox = useRef(null);
     let info = useRef(null);
     const formHandler = async () => {
      emailInputBox.current.parentElement.lastChild.innerText = "";
      nameInputBox.current.parentElement.lastChild.innerText = "";
      dobInputBox.current.parentElement.lastChild.innerText = "";
      genderInputBox.current.parentElement.lastChild.innerText = "";
      addressInputBox.current.parentElement.lastChild.innerText = "";
      info.current.innerText = "";
      let name = nameInputBox.current.value;
      let email = emailInputBox.current.value;
      let dob = dobInputBox.current.value;
      let gender = genderInputBox.current.value;
      let address = addressInputBox.current.value;

      //checking validity of inputs
      let isNameValid = (new RegExp('[A-Za-z]+$').test(name));
      let isEmailValid = (/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/).test(email);

      if ( isNameValid && isEmailValid) {
        try {
          let response = await axios.post("http://localhost:7777/addrecord", { name, email, dob,gender,address });
          console.log(name, email, dob,gender,address);
          info.current.innerText = response.data.message;
      }
      catch (err) {
          if (err.response) {
              info.current.innerText = err.response.data.message;
          }
        }
      }
      else {
        if (!isEmailValid) {
            emailInputBox.current.parentElement.lastChild.innerText = "please enter valid email";
        }
        if (!isNameValid) {
            nameInputBox.current.parentElement.lastChild.innerText = "please enter valid name.";
        }
        
    }
  }
    return (
<div id="content">
           
                <div className="container">
                    <h2>Form to add Records </h2>
                    <div className="row">
                        <div className="col-md-12">
                            <form action="#">
                                <div className="mb-3">
                                    <label htmlFor="exampleInputName1" className="form-label">Name</label>
                                    <input ref={nameInputBox} type="text" className="form-control" id="exampleInputName1" aria-describedby="nameHelp"/>
                                    <p className="validation-error"></p>
                                  </div>
                                  <div className="mb-3">
                                    <label htmlFor="exampleInputEmail1" className="form-label">Email address</label>
                                    <input ref={emailInputBox} type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"/>
                                    <div id="emailHelp" className="form-text">We&apos;ll never share your email with anyone else.</div>
                                    <p className="validation-error"></p>

                                  </div>
                                  
                                  <div className="mb-3">

                                  <label for="start">Date of Birth</label>

<input ref={dobInputBox} type="date"
       className="form-control"
     ></input>
                                         </div>
<label>Select your Gender</label>
<div>
                                  <div class="form-check form-check-inline" >
  <input ref={genderInputBox} class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="male"/>
  <label class="form-check-label" for="inlineRadio1">Male</label>
</div>
<div class="form-check form-check-inline">
  <input ref={genderInputBox} class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="female"/>
  <label class="form-check-label" for="inlineRadio2">Female</label>
</div>
</div>
                                  <div className="mb-3">
                                    <label htmlFor="exampleFormControlTextarea1" className="form-label">Address</label>
                                    
                                    
                                  <textarea ref={addressInputBox} className="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                                  <p className="validation-error"></p>
                                  </div>
                                <button type="button" className="btn btn-success" onClick={formHandler}>Add record</button>
                                <a href="/records"><button type="button" class="btn btn-primary">View all Records</button>
                                </a>

                                <p className="alert-message" ref={info}></p>
                              </form>
                        </div>
    
                        
                    </div>
                </div>
                <p class="h2">This project is built by Saif ali as a task given by Spraxa Solutions pvt.ltd  </p>
                <p class="h2">contact no - 7351943349 </p>
                <p class="h2">email-saifalikhanturkey@gmail.com</p>

        </div>


    )
   
}