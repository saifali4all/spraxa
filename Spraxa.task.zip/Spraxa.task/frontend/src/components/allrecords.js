/**
 * @author Saif Ali
 * @summary Maintains contactform Component.
 * @version 1.0
 */
 import React from "react";
 import axios from "axios";
 export const Allrecords = ()=>{
    const [Records, setRecords] = React.useState([]);
    
    React.useEffect(() => {
    
        axios.get("http://localhost:7777/getallrecord").then((response) => {     
            setRecords(response.data.record);
        });
    
      }, []);
      if (!Records) return <div><h1>No Record found</h1></div>;
      return (
        <div class="row">
                              {Records.map((curdata) => {
const {_id,name,email,dob,gender,address}=curdata
return (
        
        <div class="col-sm-3" key={_id}>
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Name-{name}</h5>
              <p class="card-text">Email-{email}</p>
              <p class="card-text">Date of birth-{dob}</p>
              <p class="card-text">Gender-{gender}</p>
              <p class="card-text">address-{address}</p>    
            <button type="button" class="btn btn-danger"onClick={async(_id)=>{
await axios.delete(`http://localhost:7777/deleterecord?id=${_id}`)
await axios.get("http://localhost:7777/getallrecord").then((response) => {     
    setRecords(response.data.record);
});
            }}>Delete</button>

            </div>
          </div>
        </div>
        
         );
        })}
        <a href="/"><button type="button" class="btn btn-primary">Add More Record</button>
</a>

       </div>
        )
    }