import {Contactform} from "./components/form"
import { BrowserRouter, Route, Routes } from "react-router-dom";
import{Allrecords} from "./components/allrecords"
function App() {
  return (
     <BrowserRouter>
      <Routes>
<Route exact path="/" element={<Contactform/>} />
        <Route exact path="/records" element={<Allrecords/>} />  
        </Routes>
              </BrowserRouter>
        );
}

export default App;
