const Record = require("./model");
const catchAsyncErrors = require("./middleware/catchAsyncErrors");

exports.addrecord = catchAsyncErrors(async (req, res,next ) => {

const { name, email, dob,gender,address } = req.body;

const record=await Record.create({name,email,dob,gender,address});
res.status(200).json({ message: 'record added succesfully',
record })
}),
exports.deleterecord = catchAsyncErrors(async (req, res,next) => {
    const record=await Record.findById(req.params.id);
    await Record.deleteOne(record)
    res.status(200).json({
        success: true,
        message: "Record Deleted Successfully",
      })
    }),
    exports.getAllRecord = catchAsyncErrors(async (req, res, next) => {
      const record = await Record.find();
    
      res.status(200).json({
        record,
      });
    });

