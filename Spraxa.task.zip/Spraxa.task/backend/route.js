const express = require("express");
const {addrecord,deleterecord,getAllRecord} = require("./controller");
const router = express.Router();
router.route("/addrecord").post(addrecord);
router.route("/deleterecord").delete(deleterecord);
router.route("/getallrecord").get(getAllRecord);
module.exports =router;