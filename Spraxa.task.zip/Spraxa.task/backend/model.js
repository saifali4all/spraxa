const mongoose = require("mongoose");

const recordSchema = new mongoose.Schema({
    name: {
      type: String,
      required: [true, "Please Enter Your Name"]
    },
    email: {
      type: String,
      required: [true, "Please Enter Your Email"]
    },
    dob: { type: Date , required: [true, 'Date of birth must be provided']},
    gender: { type: String , required: [true, 'Gender must be provided']},
    address: {
        type: String,
        required: true
      }
    });
      module.exports = mongoose.model("Record", recordSchema);

